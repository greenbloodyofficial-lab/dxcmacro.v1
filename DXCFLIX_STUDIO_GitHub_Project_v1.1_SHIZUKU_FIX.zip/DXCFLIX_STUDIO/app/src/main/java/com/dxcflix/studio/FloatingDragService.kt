package com.dxcflix.studio

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.view.animation.AlphaAnimation
import android.widget.*

class FloatingDragService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private var expanded = true
    private var locked = false
    private var params: WindowManager.LayoutParams? = null
    private val green=Color.rgb(0,255,53);private val black=Color.rgb(2,8,4)
    override fun onCreate(){super.onCreate();if(!Settings.canDrawOverlays(this)){stopSelf();return};startNotification();wm=getSystemService(WINDOW_SERVICE) as WindowManager;showOverlay()}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{if(intent?.action=="CLOSE")stopSelf();return START_STICKY}
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onDestroy(){try{root?.let{wm.removeView(it)}}catch(_:Throwable){};root=null;super.onDestroy()}

    private fun startNotification(){if(Build.VERSION.SDK_INT>=26){val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager;nm.createNotificationChannel(NotificationChannel("dxcflix_overlay","DXCFLIX Floating Controls",NotificationManager.IMPORTANCE_LOW))};val n=if(Build.VERSION.SDK_INT>=26)Notification.Builder(this,"dxcflix_overlay") else Notification.Builder(this);n.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("DXCFLIX STUDIO running").setContentText("Floating macro controls are active").setOngoing(true);startForeground(73,n.build())}

    private fun showOverlay(){
        val container=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(8),dp(8),dp(8));background=shape(Color.rgb(4,13,7),green,18);elevation=dp(12).toFloat()}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val logo=ImageView(this).apply{setImageResource(R.drawable.dxcflix_logo);scaleType=ImageView.ScaleType.CENTER_CROP;clipToOutline=true;background=shape(Color.BLACK,green,50)};header.addView(logo,LinearLayout.LayoutParams(dp(30),dp(30)))
        val brand=TextView(this).apply{text="DXCFLIX  •  MACRO";textSize=11f;setTextColor(green);typeface=Typeface.DEFAULT_BOLD;setPadding(dp(6),dp(5),dp(5),dp(5))};header.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        lateinit var lockButton: TextView;lockButton=smallButton(if(locked)"🔒" else "↔"){locked=!locked;lockButton.text=if(locked)"🔒" else "↔";Toast.makeText(this@FloatingDragService,if(locked)"Position locked" else "Position unlocked",Toast.LENGTH_SHORT).show()};header.addView(lockButton);lateinit var collapseButton: TextView;collapseButton=smallButton("−"){toggleExpand();collapseButton.text=if(expanded)"−" else "+"};header.addView(collapseButton);val close=smallButton("×"){stopSelf()};header.addView(close);container.addView(header)
        val trigger=TextView(this).apply{text="▶  HIGH DRAG";textSize=14f;gravity=Gravity.CENTER;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.BLACK);background=shape(green,green,14);setPadding(dp(13),dp(15),dp(13),dp(15));setOnClickListener{alpha=.65f;postDelayed({alpha=1f},120);val c=ConfigStore.load(this@FloatingDragService);MacroRunner.execute(this@FloatingDragService,c){ok,msg->handler.post{Toast.makeText(this@FloatingDragService,if(ok)"✓ Drag sent" else msg,Toast.LENGTH_SHORT).show()}}}}
        trigger.startAnimation(AlphaAnimation(.82f,1f).apply{duration=900;repeatMode=android.view.animation.Animation.REVERSE;repeatCount=android.view.animation.Animation.INFINITE})
        container.addView(trigger,LinearLayout.LayoutParams(-1,dp(53)).apply{setMargins(0,dp(7),0,dp(6))})
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        controls.addView(smallButton("⚙"){val i=packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);if(i!=null)startActivity(i)})
        controls.addView(smallButton("ⓘ"){Toast.makeText(this@FloatingDragService,"DXCFLIX STUDIO · Floating macro ready",Toast.LENGTH_SHORT).show()})
        controls.addView(smallButton("■"){stopSelf()})
        container.addView(controls)
        header.setOnTouchListener { _,e ->
            if(locked)return@setOnTouchListener true
            when(e.action){MotionEvent.ACTION_DOWN->{startX=e.rawX;startY=e.rawY;origX=params?.x?:0;origY=params?.y?:0;true};MotionEvent.ACTION_MOVE->{params?.let{it.x=origX+(e.rawX-startX).toInt();it.y=origY+(e.rawY-startY).toInt();try{wm.updateViewLayout(container,it)}catch(_:Throwable){}};true};else->true}
        }
        root=container
        params=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=dp(12);y=dp(180)}
        try{wm.addView(container,params)}catch(_:Throwable){stopSelf()}
        container.startAnimation(AlphaAnimation(.2f,1f).apply{duration=260})
    }
    private var startX=0f;private var startY=0f;private var origX=0;private var origY=0
    private val handler=android.os.Handler(android.os.Looper.getMainLooper())
    private fun toggleExpand(){expanded=!expanded;root?.let{v->if(v.childCount>2){v.getChildAt(2).visibility=if(expanded)View.VISIBLE else View.GONE};if(v.childCount>1)v.getChildAt(1).visibility=View.VISIBLE}}
    private fun smallButton(t:String,fn:()->Unit)=TextView(this).apply{text=t;textSize=16f;gravity=Gravity.CENTER;setTextColor(green);background=shape(Color.rgb(10,27,15),Color.rgb(35,100,50),12);setPadding(dp(10),dp(7),dp(10),dp(7));setOnClickListener{fn()};layoutParams=LinearLayout.LayoutParams(dp(43),dp(39)).apply{setMargins(dp(3),0,dp(3),0)}}
    private fun shape(color:Int,stroke:Int,r:Int)=GradientDrawable().apply{setColor(color);cornerRadius=dp(r).toFloat();setStroke(dp(1),stroke)}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
