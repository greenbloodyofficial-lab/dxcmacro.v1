package com.dxcflix.studio

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONObject
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dxc_studio", MODE_PRIVATE) }
    private val bg = Color.rgb(3, 6, 4); private val green = Color.rgb(40,255,85); private val muted = Color.rgb(151,177,158)
    private lateinit var root: LinearLayout
    private var distance=220; private var duration=120; private var offset=8; private var cooldown=100
    private var sx=540f; private var sy=1500f; private var ex=548f; private var ey=1280f
    private var logBox: LinearLayout?=null
    private val shizukuRequestCode = 7401
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refreshPermissionPageIfVisible() } }
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
        if (requestCode == shizukuRequestCode) runOnUiThread {
            toast(if (MacroRunner.shizukuState() == "Connected") "Shizuku permission granted" else "Shizuku permission not granted")
            refreshPermissionPageIfVisible()
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=bg; window.navigationBarColor=bg; load(); try { Shizuku.addBinderReceivedListener(binderListener); Shizuku.addRequestPermissionResultListener(permissionListener) } catch (_: Throwable) {}; dashboard() }
    override fun onResume() { super.onResume(); refreshPermissionPageIfVisible() }
    override fun onDestroy() { try { Shizuku.removeBinderReceivedListener(binderListener); Shizuku.removeRequestPermissionResultListener(permissionListener) } catch (_: Throwable) {}; super.onDestroy() }
    private fun refreshPermissionPageIfVisible() { if (::root.isInitialized && root.tag == "permission") permissions() }
    private fun load(){ distance=prefs.getInt("distance",220);duration=prefs.getInt("duration",120);offset=prefs.getInt("offset",8);cooldown=prefs.getInt("cooldown",100);sx=prefs.getFloat("sx",540f);sy=prefs.getFloat("sy",1500f);ex=prefs.getFloat("ex",548f);ey=prefs.getFloat("ey",1280f) }
    private fun save(){prefs.edit().putInt("distance",distance).putInt("duration",duration).putInt("offset",offset).putInt("cooldown",cooldown).putFloat("sx",sx).putFloat("sy",sy).putFloat("ex",ex).putFloat("ey",ey).apply(); toast("Configuration saved")}
    private fun dashboard(){
        root=LinearLayout(this).apply{orientation=1;setPadding(dp(16),dp(12),dp(16),dp(24));setBackgroundColor(bg)}
        val scroll=ScrollView(this);scroll.addView(root);setContentView(scroll)
        val header=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val logo=ImageView(this).apply{setImageResource(R.drawable.dxcflix_logo);scaleType=ImageView.ScaleType.CENTER_CROP;clipToOutline=true;background=shape(Color.BLACK,green,100)}
        header.addView(logo,LinearLayout.LayoutParams(dp(72),dp(72)))
        val brand=LinearLayout(this).apply{orientation=1;setPadding(dp(12),0,0,0)}
        brand.addView(txt("DXCFLIX STUDIO",24f,Color.WHITE,true));brand.addView(txt("HUD MACRO CONTROL CENTER",10f,green,true));header.addView(brand);root.addView(header)
        val status=card();status.addView(txt("●  DEVICE READY  ·  ${Build.MANUFACTURER} ${Build.MODEL}",12f,green,true));status.addView(txt("Android ${Build.VERSION.RELEASE}  |  API ${Build.VERSION.SDK_INT}",11f,muted,false));root.addView(status)
        section("CONTROL CENTER")
        val start=btn("START FLOATING HUD WINDOW",true){startOverlay()};root.addView(start)
        val stop=btn("STOP FLOATING WINDOW",false){stopService(Intent(this,FloatingDragService::class.java));stopService(Intent(this,HudOverlayService::class.java));toast("Floating windows stopped")};root.addView(stop)
        val row=LinearLayout(this);row.addView(btn("HUD EDITOR",false){hudEditor()},LinearLayout.LayoutParams(0,-2,1f));row.addView(btn("MACRO STUDIO",false){recorder()},LinearLayout.LayoutParams(0,-2,1f));root.addView(row)
        section("MACRO CONFIGURATION")
        val c=card();c.addView(txt("Distance: $distance px   ·   Duration: $duration ms",14f,Color.WHITE,true));c.addView(txt("Offset: $offset px   ·   Cooldown: $cooldown ms",12f,muted,false));c.addView(btn("OPEN PRECISION TUNING",false){tuning()});root.addView(c)
        section("TOOLS & SAFETY")
        root.addView(btn("PERMISSION & COMPATIBILITY CHECK",false){permissions()})
        root.addView(btn("BACKUP / RESTORE CONFIGURATION",false){backup()})
        root.addView(btn("ACTIVITY LOG",false){logs()})
        root.addView(btn("OPEN DXCFLIX YOUTUBE CHANNEL",false){startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/@dxcflixstudio")))})
        root.addView(txt("AMOLED BLACK  ·  NEON GREEN  ·  v1.0.0",10f,muted,true).apply{gravity=Gravity.CENTER;setPadding(0,dp(20),0,0)})
    }
    private fun hudEditor(){ page("HUD VISUAL EDITOR","Position and size guide for your game HUD")
        val info=card();info.addView(txt("HUD MARKER PREVIEW",14f,green,true));val preview=FrameLayout(this).apply{setBackgroundColor(Color.rgb(8,15,10))}
        val marker=TextView(this).apply{text="FIRE";gravity=Gravity.CENTER;setTextColor(Color.BLACK);textSize=11f;setBackground(shape(green,green,100));elevation=10f}
        val lp=FrameLayout.LayoutParams(dp(64),dp(64),Gravity.CENTER);preview.addView(marker,lp);info.addView(preview,LinearLayout.LayoutParams(-1,dp(220)))
        info.addView(txt("This marker is a visual alignment guide. It does not capture or inject touches into another game.",11f,muted,false));root.addView(info)
        root.addView(btn("LOCK MARKER POSITION (PREVIEW)",false){marker.isEnabled=false;toast("Preview marker locked")})
        root.addView(btn("SHOW FLOATING CONTROL",true){startOverlay()})
        root.addView(btn("BACK TO DASHBOARD",false){dashboard()})
    }
    private fun recorder(){ page("MACRO RECORDING STUDIO","Record a gesture inside this app and save its path")
        val c=card();c.addView(txt("GESTURE CANVAS",14f,green,true));val canvas=GestureCanvas(this);c.addView(canvas,LinearLayout.LayoutParams(-1,dp(280)));root.addView(c)
        root.addView(btn("CLEAR RECORDING",false){canvas.clear()});root.addView(btn("SAVE GESTURE CONFIGURATION",true){sx=canvas.x1;sy=canvas.y1;ex=canvas.x2;ey=canvas.y2;distance=kotlin.math.abs((sy-ey).toInt());save()})
        root.addView(txt("Note: Android does not allow ordinary apps to silently record touches inside other apps. This recorder captures gestures on this app's own canvas only.",11f,muted,false));root.addView(btn("BACK",false){dashboard()})
    }
    private fun tuning(){page("PRECISION TUNING","Adjust and store the visual macro parameters")
        distance=slider("Drag distance",20,600,distance){distance=it};duration=slider("Duration (ms)",20,1000,duration){duration=it};offset=slider("Horizontal offset",-100,100,offset){offset=it};cooldown=slider("Cooldown (ms)",50,1000,cooldown){cooldown=it}
        root.addView(btn("SAVE SETTINGS",true){save();dashboard()});root.addView(btn("RESET DEFAULTS",false){distance=220;duration=120;offset=8;cooldown=100;save();tuning()});root.addView(btn("BACK",false){dashboard()})
    }
    private fun permissions(){page("PERMISSION CENTER","Android compatibility · Overlay · Shizuku")
        root.tag = "permission"
        val overlay=card();overlay.addView(txt("Overlay permission: ${if(Settings.canDrawOverlays(this))"GRANTED" else "NOT GRANTED"}",14f,if(Settings.canDrawOverlays(this))green else Color.YELLOW,true));overlay.addView(btn("GRANT / CHECK OVERLAY PERMISSION",false){if(!Settings.canDrawOverlays(this)){try{startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))}catch(_:Throwable){toast("Open Android Settings → Apps → Special app access → Display over other apps")}}else toast("Overlay permission already granted")});root.addView(overlay)
        val state = MacroRunner.shizukuState()
        val sh=card();sh.addView(txt("Shizuku status: $state",14f,if(state=="Connected")green else Color.YELLOW,true))
        sh.addView(txt("1. Install and open the official Shizuku app.  2. Start Shizuku using Wireless debugging or USB debugging.  3. Return here and grant DXCFLIX STUDIO permission.",11f,muted,false))
        sh.addView(btn("CHECK SHIZUKU CONNECTION",false){toast("Shizuku: ${MacroRunner.shizukuState()}");permissions()})
        sh.addView(btn("REQUEST SHIZUKU PERMISSION",true){try{if(!Shizuku.pingBinder()){toast("Shizuku is not running. Start it in the Shizuku app first.")}else if(Shizuku.checkSelfPermission()==android.content.pm.PackageManager.PERMISSION_GRANTED){toast("Shizuku permission already granted")}else{Shizuku.requestPermission(shizukuRequestCode)}}catch(e:Throwable){toast("Shizuku unavailable: ${e.message}")}})
        sh.addView(btn("OPEN SHIZUKU APP",false){val launch=packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api");if(launch!=null)startActivity(launch)else toast("Install the official Shizuku app first")});root.addView(sh)
        root.addView(txt("Important: Shizuku permission is granted by the Shizuku app, not by Android's overlay permission screen. Game compatibility and anti-cheat restrictions may still block input automation.",11f,muted,false));root.addView(btn("BACK",false){dashboard()})
    }
    private fun backup(){val j=JSONObject().put("distance",distance).put("duration",duration).put("offset",offset).put("cooldown",cooldown).put("startX",sx).put("startY",sy).put("endX",ex).put("endY",ey);val i=Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_TEXT,j.toString(2));startActivity(Intent.createChooser(i,"Export DXCFLIX profile"))}
    private fun logs(){page("ACTIVITY LOG","Local app events");root.addView(txt("• App initialized\n• Profile loaded\n• Android ${Build.VERSION.SDK_INT} detected\n• Overlay permission: ${Settings.canDrawOverlays(this)}",13f,muted,false));root.addView(btn("BACK",false){dashboard()})}
    private fun page(title:String,sub:String){root.tag = null;root.removeAllViews();root.addView(txt("‹  DXCFLIX STUDIO",13f,green,true).apply{setOnClickListener{dashboard()}});root.addView(txt(title,23f,Color.WHITE,true));root.addView(txt(sub,11f,muted,false))}
    private fun section(s:String){root.addView(txt(s,11f,green,true).apply{setPadding(2,dp(18),0,dp(7))})}
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=1;setPadding(dp(14),dp(12),dp(14),dp(12));background=shape(Color.rgb(10,22,14),Color.rgb(26,91,45),16);layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)}}
    private fun txt(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply{text=s;textSize=size;setTextColor(color);if(bold)setTypeface(typeface,1);setPadding(0,dp(4),0,dp(4))}
    private fun btn(s:String,primary:Boolean,on:()->Unit)=Button(this).apply{text=s;textSize=11f;isAllCaps=false;setTextColor(if(primary)Color.BLACK else Color.WHITE);background=shape(if(primary)green else Color.rgb(12,29,18),if(primary)green else Color.rgb(34,112,55),14);setPadding(dp(8),dp(7),dp(8),dp(7));layoutParams=LinearLayout.LayoutParams(-1,dp(49)).apply{bottomMargin=dp(8)};setOnClickListener{on()}}
    private fun slider(label:String,min:Int,max:Int,value:Int,changed:(Int)->Unit):Int{val box=card();val t=txt("$label: $value",13f,Color.WHITE,true);box.addView(t);val seek=SeekBar(this).apply{this.max=max-min;progress=(value-min).coerceIn(0,max-min);progressTintList=android.content.res.ColorStateList.valueOf(green);thumbTintList=android.content.res.ColorStateList.valueOf(green)};seek.setOnSeekBarChangeListener(object:android.widget.SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){t.text="$label: ${p+min}";changed(p+min)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}});box.addView(seek);root.addView(box);return value}
    private fun startOverlay(){if(!Settings.canDrawOverlays(this)){try{startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))}catch(_:Throwable){};toast("Allow Display over other apps, then tap Start again");return};try{val i=Intent(this,FloatingDragService::class.java);if(Build.VERSION.SDK_INT>=26)startForegroundService(i)else startService(i);toast("Floating macro controls started")}catch(e:Throwable){toast("Could not start floating controls: ${e.message}")}}
    private fun shape(color:Int,stroke:Int,r: Int)=GradientDrawable().apply{setColor(color);cornerRadius=dp(r).toFloat();setStroke(dp(1),stroke)}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    inner class GestureCanvas(ctx:Context):View(ctx){var x1=0f;var y1=0f;var x2=0f;var y2=0f;private val p=Paint(3).apply{color=green;strokeWidth=5f;style=Paint.Style.STROKE};override fun onDraw(c:Canvas){super.onDraw(c);c.drawColor(Color.rgb(4,10,6));for(x in 0..width step dp(24))c.drawLine(x.toFloat(),0f,x.toFloat(),height.toFloat(),Paint().apply{color=0xff17351f.toInt();strokeWidth=1f});for(y in 0..height step dp(24))c.drawLine(0f,y.toFloat(),width.toFloat(),y.toFloat(),Paint().apply{color=0xff17351f.toInt();strokeWidth=1f});if(x1!=0f){c.drawLine(x1,y1,x2,y2,p);c.drawCircle(x1,y1,dp(8).toFloat(),p);c.drawCircle(x2,y2,dp(8).toFloat(),p)}};override fun onTouchEvent(e:MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->{x1=e.x;y1=e.y;x2=x1;y2=y1;invalidate();return true};MotionEvent.ACTION_MOVE->{x2=e.x;y2=e.y;invalidate();return true};MotionEvent.ACTION_UP->{x2=e.x;y2=e.y;invalidate();return true}};return true};fun clear(){x1=0f;y1=0f;x2=0f;y2=0f;invalidate()}}
}
