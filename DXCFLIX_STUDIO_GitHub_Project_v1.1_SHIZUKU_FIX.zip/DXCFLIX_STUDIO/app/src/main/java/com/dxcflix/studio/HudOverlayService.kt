package com.dxcflix.studio

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class HudOverlayService : Service() {
    private lateinit var wm:WindowManager
    private var marker:TextView?=null
    private var panel:LinearLayout?=null
    private var locked=false
    private var hidden=false
    private var size=64
    private var markerLp:WindowManager.LayoutParams?=null
    override fun onCreate(){super.onCreate();startStatusNotification();wm=getSystemService(WINDOW_SERVICE) as WindowManager;showMarker();showPanel()}
    private fun startStatusNotification(){
        val manager=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT>=26){manager.createNotificationChannel(NotificationChannel("dxc_hud","DXCFLIX HUD Controls",NotificationManager.IMPORTANCE_LOW))}
        val n=if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,"dxc_hud") else Notification.Builder(this)
        n.setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("DXCFLIX HUD guide active").setContentText("Floating visual controls are running").setOngoing(true)
        startForeground(41,n.build())
    }
    private fun type()=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun params(w:Int,h:Int)=WindowManager.LayoutParams(w,h,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=80;y=300}
    private fun bg(color:Int,stroke:Int)=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(color);setStroke(2,stroke)}
    private fun showMarker(){if(marker!=null)return;val v=TextView(this).apply{text="HUD";textSize=11f;gravity=Gravity.CENTER;setTextColor(Color.BLACK);background=bg(0xff28ff55.toInt(),Color.WHITE);elevation=12f;setOnTouchListener(object:View.OnTouchListener{var sx=0f;var sy=0f;var ox=0;var oy=0;override fun onTouch(view:View,e:MotionEvent):Boolean{val lp=markerLp?:return false;when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=lp.x;oy=lp.y;return true};MotionEvent.ACTION_MOVE->{if(!locked){lp.x=ox+(e.rawX-sx).toInt();lp.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(view,lp)};return true};MotionEvent.ACTION_UP->{Toast.makeText(this@HudOverlayService,"HUD guide marker · visual only",Toast.LENGTH_SHORT).show();return true}};return true}})};val lp=params(size,size);markerLp=lp;marker=v;wm.addView(v,lp)}
    private fun showPanel(){if(panel!=null)return;val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,8,10,8);background=GradientDrawable().apply{setColor(0xee061009.toInt());cornerRadius=22f;setStroke(2,0xff28ff55.toInt())}}
        val head=TextView(this).apply{text="DXCFLIX  ·  HUD TOOLS";setTextColor(0xff28ff55.toInt());textSize=12f;setPadding(4,6,4,8)};box.addView(head)
        fun action(label:String,fn:()->Unit){val b=Button(this).apply{text=label;textSize=10f;isAllCaps=false;setTextColor(Color.WHITE);background=GradientDrawable().apply{setColor(0xff102418.toInt());cornerRadius=14f;setStroke(1,0xff277b40.toInt())};setOnClickListener{fn()}};box.addView(b,LinearLayout.LayoutParams(-1,42).apply{bottomMargin=5})}
        action(if(locked)"UNLOCK POSITION" else "LOCK POSITION"){locked=!locked;Toast.makeText(this,if(locked)"Position locked" else "Position unlocked",Toast.LENGTH_SHORT).show()}
        action(if(hidden)"SHOW HUD MARKER" else "HIDE HUD MARKER"){if(hidden){showMarker();hidden=false}else{marker?.let{wm.removeView(it)};marker=null;hidden=true}}
        action("RESIZE MARKER +"){size=(size+8).coerceAtMost(120);marker?.let{wm.removeView(it)};marker=null;showMarker()}
        action("RESIZE MARKER −"){size=(size-8).coerceAtLeast(32);marker?.let{wm.removeView(it)};marker=null;showMarker()}
        action("OPEN DXCFLIX APP"){val i=packageManager.getLaunchIntentForPackage(packageName);i?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);if(i!=null)startActivity(i)}
        action("CLOSE FLOATING TOOLS"){stopSelf()}
        panel=box;val lp=params( dp(174),-2).apply{x=10;y=100};wm.addView(box,lp)
    }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onDestroy(){marker?.let{try{wm.removeView(it)}catch(_:Exception){}};panel?.let{try{wm.removeView(it)}catch(_:Exception){}};marker=null;panel=null;super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
