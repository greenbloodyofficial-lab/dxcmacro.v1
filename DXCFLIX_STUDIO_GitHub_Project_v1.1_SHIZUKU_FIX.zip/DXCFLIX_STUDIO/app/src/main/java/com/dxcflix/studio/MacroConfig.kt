package com.dxcflix.studio

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import rikka.shizuku.Shizuku
import java.lang.reflect.InvocationTargetException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

 data class MacroConfig(
    var x1: Int = 540,
    var y1: Int = 1500,
    var distance: Int = 220,
    var duration: Int = 120,
    var offset: Int = 8,
    var cooldown: Int = 100,
    var screenWidth: Int = 1080,
    var screenHeight: Int = 2400,
    var orientation: Int = 0
) {
    val x2: Int get() = (x1 + offset).coerceIn(0, screenWidth - 1)
    val y2: Int get() = (y1 - distance).coerceIn(0, screenHeight - 1)
}

object ConfigStore {
    private const val FILE = "dxcflix_config"
    private fun prefs(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun load(c: Context): MacroConfig {
        val p = prefs(c)
        return MacroConfig(
            p.getInt("x1", 540), p.getInt("y1", 1500), p.getInt("distance", 220),
            p.getInt("duration", 120), p.getInt("offset", 8), p.getInt("cooldown", 100),
            p.getInt("width", 1080), p.getInt("height", 2400), p.getInt("orientation", 0)
        )
    }
    fun save(c: Context, v: MacroConfig) {
        prefs(c).edit().putInt("x1",v.x1).putInt("y1",v.y1).putInt("distance",v.distance)
            .putInt("duration",v.duration).putInt("offset",v.offset).putInt("cooldown",v.cooldown)
            .putInt("width",v.screenWidth).putInt("height",v.screenHeight).putInt("orientation",v.orientation).apply()
    }
    fun reset(c: Context) = save(c, MacroConfig())
    fun saveProfile(c: Context, name: String, v: MacroConfig) {
        val p = prefs(c).edit()
        val prefix = "profile_${name.trim().ifBlank { "Default" }}_"
        p.putInt(prefix+"x1",v.x1).putInt(prefix+"y1",v.y1).putInt(prefix+"distance",v.distance)
            .putInt(prefix+"duration",v.duration).putInt(prefix+"offset",v.offset).putInt(prefix+"cooldown",v.cooldown)
            .putInt(prefix+"width",v.screenWidth).putInt(prefix+"height",v.screenHeight).putInt(prefix+"orientation",v.orientation).apply()
        p.putStringSet("profiles", (prefs(c).getStringSet("profiles", emptySet()) ?: emptySet()) + name.trim()).apply()
    }
    fun profiles(c: Context): Set<String> = prefs(c).getStringSet("profiles", setOf("Default")) ?: setOf("Default")
    fun loadProfile(c: Context, name: String): MacroConfig {
        val p=prefs(c); val k="profile_${name}_"; val d=load(c)
        return MacroConfig(p.getInt(k+"x1",d.x1),p.getInt(k+"y1",d.y1),p.getInt(k+"distance",d.distance),p.getInt(k+"duration",d.duration),p.getInt(k+"offset",d.offset),p.getInt(k+"cooldown",d.cooldown),p.getInt(k+"width",d.screenWidth),p.getInt(k+"height",d.screenHeight),p.getInt(k+"orientation",d.orientation))
    }
}

object MacroRunner {
    private val worker = Executors.newSingleThreadExecutor()
    private val lastRun = AtomicLong(0)
    @Volatile private var running = false

    fun shizukuState(): String = try {
        when {
            !Shizuku.pingBinder() -> "Not running"
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> "Permission required"
            else -> "Connected"
        }
    } catch (_: Throwable) { "Unavailable" }

    fun requestShizuku(requestCode: Int = 1001) {
        try { if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(requestCode) } catch (_: Throwable) { }
    }

    fun execute(c: Context, config: MacroConfig, callback: (Boolean, String) -> Unit = { _, _ -> }) {
        val state = shizukuState()
        if (state != "Connected") { callback(false, "Shizuku: $state. Start Shizuku and grant permission first."); return }
        val now = System.currentTimeMillis()
        val previous = lastRun.get()
        if (now - previous < config.cooldown) { callback(false, "Cooldown active — wait ${config.cooldown - (now-previous)} ms"); return }
        if (running) { callback(false, "Macro is already running"); return }
        lastRun.set(now); running = true
        worker.execute {
            var process: Process? = null
            try {
                val dm = c.resources.displayMetrics
                val width = dm.widthPixels.coerceAtLeast(1); val height = dm.heightPixels.coerceAtLeast(1)
                val sx = (config.x1.toFloat() / config.screenWidth.coerceAtLeast(1) * width).toInt().coerceIn(0,width-1)
                val sy = (config.y1.toFloat() / config.screenHeight.coerceAtLeast(1) * height).toInt().coerceIn(0,height-1)
                val ex = (config.x2.toFloat() / config.screenWidth.coerceAtLeast(1) * width).toInt().coerceIn(0,width-1)
                val ey = (config.y2.toFloat() / config.screenHeight.coerceAtLeast(1) * height).toInt().coerceIn(0,height-1)
                val command = "input swipe $sx $sy $ex $ey ${config.duration.coerceIn(20,2000)}"
                val method = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java).apply { isAccessible = true }
                process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
                val output = process.inputStream.bufferedReader().readText()
                val error = process.errorStream.bufferedReader().readText()
                val code = process.waitFor()
                val success = code == 0
                callback(success, if (success) "Swipe executed: ($sx,$sy) → ($ex,$ey), ${config.duration} ms" else "Command failed ($code): $error $output")
            } catch (e: InvocationTargetException) {
                callback(false, "Shizuku process error: ${e.targetException.message}")
            } catch (e: Throwable) { callback(false, "Execution error: ${e.message}") }
            finally { try { process?.destroy() } catch (_: Throwable) {}; running = false }
        }
    }
}
