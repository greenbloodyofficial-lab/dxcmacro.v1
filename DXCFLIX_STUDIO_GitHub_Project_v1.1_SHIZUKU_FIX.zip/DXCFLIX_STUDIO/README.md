# DXCFLIX STUDIO v1.0

Native Android project with AMOLED-black / neon-green UI, bundled DXCFLIX Studio logo, macro parameter editor, in-app gesture canvas, profile configuration export, permission diagnostics, and a draggable floating HUD visual guide.

## Build on GitHub (phone-friendly)
1. Create or open a GitHub repository.
2. Upload the **contents** of this folder to the repository root (including the hidden `.github` folder).
3. Open **Actions** → **Build DXCFLIX STUDIO APK** → **Run workflow**.
4. Download the `DXCFLIX-STUDIO-debug-apk` artifact from the completed run.

## Compatibility
- Minimum Android: 7.0 (API 24).
- Uses responsive native Android Views and system density units.
- Android 8+ is recommended. Overlay permission must be granted before starting the floating guide.
- Built with Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, compile SDK 35.

## Important functional boundary
The floating HUD marker is a draggable visual alignment guide. The gesture canvas records touches made **inside DXCFLIX STUDIO**. This project does not capture touches from another game, forward touches through an overlay, or inject game input. Android/individual games restrict those capabilities, and a transparent overlay cannot universally both consume a touch and pass the same touch to the underlying game. Macro parameters are saved for planning/calibration and can be exported as JSON text.

## Logo
The supplied DXCFLIX Studio logo is bundled at `app/src/main/res/drawable/dxcflix_logo.jpg`.


## Build fix (Shizuku references)

The Android module declares `dev.rikka.shizuku:api:13.1.5` so `rikka.shizuku.Shizuku` resolves during Kotlin compilation. The Shizuku manager must still be installed and started by the device owner, and permission must be granted at runtime. A successful APK build does not guarantee that cross-app gestures work in every game or Android version.
